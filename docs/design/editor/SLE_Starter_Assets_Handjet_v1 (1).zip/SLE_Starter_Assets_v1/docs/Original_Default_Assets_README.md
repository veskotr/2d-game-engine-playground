# SLE Default Assets v1 — Little Forest

A compact starter collection for **Simple Little Engine**. It contains runtime fallback textures and a reusable editor icon family. No external icon library or licensed font files are bundled.

## 1. Core textures (`core/`)

| Asset | Use | OpenGL hint |
|---|---|---|
| `white_pixel_1x1.png` | Tintable quads, debug lines and UI rectangles | `GL_NEAREST`, `GL_CLAMP_TO_EDGE` |
| `black_pixel_1x1.png` | Optional black/tintable solid | `GL_NEAREST`, `GL_CLAMP_TO_EDGE` |
| `transparent_pixel_1x1.png` | Optional empty placeholder texture | `GL_NEAREST`, `GL_CLAMP_TO_EDGE` |
| `default_box_64.png` | Intentional unassigned entity sprite | `GL_NEAREST`, `GL_CLAMP_TO_EDGE` |
| `missing_texture_16.png` / `_64.png` | Failed texture load: high-contrast magenta/dark checker | `GL_NEAREST`, repeat only if desired |
| `transparency_checker_16.png` / `_64.png` | Editor-only alpha-background visualization | `GL_NEAREST`, `GL_REPEAT` |

**Important:** Default/unassigned and failed/missing are different states. Never silently substitute the friendly default box when a user-provided texture path fails; show the magenta error checker and log an actionable error.

The 1×1 textures can instead be generated directly in GPU memory. Bundled PNGs are conveniences, not mandatory file-I/O dependencies.

The `_64` checker variants are nearest-neighbor scale-ups of the 16×16 bases. The default box is copied from the previously approved SLE box concept.

See `preview/core-textures-preview.png` for a visual comparison.

## 2. Forest editor icons (`editor/icons/`)

- `svg/` contains **20 editable 24×24 vector originals**. They use a consistent 1.8-unit outline stroke with rounded ends and `currentColor` for tinting. Default SVG color is `#328653`.
- `png/light/16/` and `png/light/24/` use Little Forest light-mode green `#328653`.
- `png/dark/16/` and `png/dark/24/` use Little Forest dark-mode green `#88CB91`.
- `preview/forest-icon-sheet.png` shows the full family in both themes.

Included types and controls:

`scene`, `entity`, `camera`, `sprite`, `collider`, `physics`, `lua_script`, `audio`, `animation`, `prefab`, `ui`, `tilemap`, `folder`, `resource`, `visibility`, `hidden`, `lock`, `warning`, `transform`, `add`.

### How Codex should integrate them

1. **Inspect the editor's actual UI framework and icon loading pipeline** before choosing SVG or PNG variants.
2. Prefer drawing/tinting SVG paths or equivalent vector icons directly through the theme system when supported. Otherwise, use the 16px/24px PNGs.
3. Do not force every icon to remain green: passive tree rows can use the semantic `textSecondary` color; active/selected actions can use `accent`.
4. Keep a single mapping from component/resource types to icon names. New editor features should reuse this mapping and these drawing conventions.
5. Do not stretch icons or add arbitrary paddings per panel. Default displayed size 16dp; use 24dp in menus or larger resource views.
6. Add semantic tooltips and keyboard focus indicators where the icons act as buttons.

### Adding an icon

Use the same 24×24 viewBox and ~1.8-unit rounded outline. Avoid tiny detail that disappears at 16px. Provide a neutral meaning that works in different genres, and prepare light/dark samples. Do not introduce emoji, gradients, or competing icon styles.

## 3. What is not in v1

- A bundled font: choose a redistributable, Cyrillic-capable typeface later (e.g. an OFL font), and retain its full license text.
- Starter-game tiles, characters, sounds and scripts: these should live in an **optional example project**, not the minimal engine runtime.
- Prefab override, docking, or scene tools: icons do not implement engine functionality. Connect controls only when supported.
- A manually redrawn pixel-perfect 16×16 mascot: that is separate from editor component icons.

## 4. Design intent

Charming indie identity, professional dense editor ergonomics. Green is the brand accent; neutral surfaces and clear semantic state colors remain essential for usability.
