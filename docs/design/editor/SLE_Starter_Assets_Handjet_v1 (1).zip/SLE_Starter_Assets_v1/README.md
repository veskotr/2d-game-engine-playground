# SLE Starter Assets v1 — Little Forest + Handjet

This is the current **approved SLE brand/editor/runtime starter bundle**.
It combines the previously selected SLE mascot app icon, default box texture,
editor fallback textures, theme-aware UI icons, and Handjet font. The bundle
is deliberately **not** a sample game: no tilesets or player sprites yet.

## Folder map

| Folder | Contents |
| --- | --- |
| `runtime/textures/` | White/black/transparent pixels, missing checkerboards, alpha checkerboards, default 64px box |
| `runtime/box_variants/` | The approved SLE box sprite at 32, 64, 128 and 256 pixels |
| `editor/icons/svg/` | Twenty editable theme-tintable SVG icons |
| `editor/icons/png/{light,dark}/{16,24}/` | Raster editor icons for both UI modes |
| `branding/app_icon/png/` | SLE mascot desktop/app icons (16–1024 px) |
| `branding/app_icon/windows/` | Windows `.ico` |
| `branding/app_icon/linux/` | Linux hicolor application icons |
| `fonts/handjet/` | Original Handjet TTF weights 400, 500, 600, 700 |
| `themes/little_forest.json` | Matching semantic dark/light colors and type guidance |
| `docs/` | The agreed editor design spec and original asset-pack readmes |
| `previews/` | Texture and icon contact sheets |
| `licenses/` | Handjet's SIL Open Font License 1.1 |

## Integration contract

1. Do not alter SLE's game content or editor behavior merely by adopting the theme.
2. Treat `runtime/textures/default_box_64.png` as the unassigned sprite,
   not an indicator of loading failure. For missing/invalid resources, render
   `missing_texture_16.png` or `missing_texture_64.png` and log an error.
3. Use nearest-neighbor sampling for pixel textures and clamp edges where
   appropriate. Use nearest-neighbor scaling for preview pixel art.
4. Resolve editor component icons via one centralized type-to-icon lookup.
   Use semantic UI colors, not literal colors embedded throughout feature code.
5. Handjet is the **chosen personality/branding typeface**. It is suitable for
   section titles, prominent controls and headings. At very small sizes it may
   reduce readability; retain a clear system UI typeface for dense property
   grids, trees, text fields and data, especially in the compact layout.
   The font includes Cyrillic glyphs. Actual code editing happens in VS Code.
6. Map this bundle's paths into the real project structure; these are asset
   organization suggestions, not a claimed SLE-specific asset schema.

## License and provenance

The editor icons and previously selected texture/mascot graphics are the
original SLE assets from earlier approved packs. Handjet is an open-source
typeface from Google Fonts, copyright The Handjet Project Authors, under the
**SIL Open Font License 1.1**. The full copyright notice and license are in
`licenses/Handjet-OFL.txt` and must stay with redistributed font files.

Original font source: https://fonts.google.com/specimen/Handjet

## Next stages (not bundled)

The starter game/forest tileset, animated hero, SFX and sample Lua game
scripts are intentionally deferred. The UI design spec is in
`docs/SLE_EDITOR_UI_DESIGN.md` for future Codex work.
