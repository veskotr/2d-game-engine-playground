# SLE default box texture

This is a neutral 2D *placeholder sprite* for SLE entities, styled in the Little Forest palette. It is intentionally recognizable as an editor placeholder rather than a wooden crate or finished game asset.

- `sle_default_box_64.png` — recommended base texture (64×64, opaque RGB).
- `sle_default_box_32.png` — small thumbnail / 32×32 sprites.
- `sle_default_box_128.png` — high-DPI usage.
- `sle_default_box_256.png` — asset browser previews and higher-resolution use.

## Engine use

- Assign the 64×64 PNG as the **default box/entity placeholder** when no artistic sprite has been chosen.
- Pixel-oriented art looks best with `GL_NEAREST` magnification and, if appropriate, nearest-style minification.
- This texture has an edge border and is **not seamless/tileable**; use `GL_CLAMP_TO_EDGE` if the texture is meant to cover a single box rather than repeat across a surface.
- An *asset load failure* is different from an *intentionally unassigned box texture*. Consider a separate high-contrast magenta/black missing-texture warning later.
- The green squares and center marker indicate a placeholder and make orientation visible.

The illustration was generated as a concept and resampled to practical pixel dimensions. For final shipping, the checkerboard/marker can be redrawn deterministically pixel-for-pixel if desired.
