SLE (Simple Little Engine) - Mascot Icon Pack
=============================================

Mascot: current excited/cheerful version (name to be decided).
Source: generated raster illustration, not yet a manually redrawn SVG.

CONTENTS
  png/sle-SIZE.png                  Transparent RGBA square PNGs
  windows/sle.ico                   Multi-resolution ICO for Windows
  linux/hicolor/SIZExSIZE/apps/sle.png  Linux freedesktop icon hierarchy
  preview/icon-size-preview.png     Light and dark size comparison

PNG sizes: 16, 20, 22, 24, 32, 40, 48, 64, 96, 128, 192, 256, 512, 1024.
Windows ICO embedded sizes: 16, 24, 32, 48, 64, 128, 256.

SUGGESTED USE
  Windows: windows/sle.ico for the application/executable shortcut icon.
  Linux: copy the linux/hicolor directories into the application's icon tree,
         or use a png/sle-256.png as an icon asset.
  UI/app branding: png/sle-128.png or png/sle-256.png.

All exports retain actual transparency; each preserves the original mascot
proportions, centered inside a square with a small margin. At very small sizes,
some face and hardware details will naturally disappear. A hand-optimized
16x16 version can be developed when the mascot design is finalized.
